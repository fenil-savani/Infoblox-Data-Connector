"""This File contains custom Exception class for Infoblox TIDE."""


class InfobloxException(Exception):
    """Exception class to handle Infoblox exception.

    Args:
        Exception (string): Prints exception message.
    """

    def __init__(self, message=None) -> None:
        """Initialize custom InfobloxException with custom message."""
        super().__init__(message)
