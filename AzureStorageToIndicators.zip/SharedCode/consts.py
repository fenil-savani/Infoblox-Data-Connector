"""This file contains all constants."""

import os

AZURE_CLIENT_ID = os.environ.get("Azure_Client_Id", "")
AZURE_CLIENT_SECRET = os.environ.get("Azure_Client_Secret", "")
AZURE_TENANT_ID = os.environ.get("Azure_Tenant_Id", "")
LOG_LEVEL = os.environ.get("LogLevel")

LOGS_STARTS_WITH = "Infoblox TIDE"
AZURE_AUTHENTICATION_URL = "https://login.microsoftonline.com/{}/oauth2/v2.0/token"
UPLOAD_SENTINEL_INDICATORS_URL = "https://sentinelus.azure-api.net/{}/threatintelligence:upload-indicators?api-version=2022-07-01"


CONNECTION_STRING = os.environ.get("Connection_String", "")
WORKSPACE_KEY = os.environ.get("Workspace_Key", "")
WORKSPACE_ID = os.environ.get("Workspace_Id", "")

CONFIDENCE_THRESHOLD = int(os.environ.get("Confidence_Threshold", ""))
THREAT_LEVEL = int(os.environ.get("Threat_Level", ""))


THREATS_TABLE_NAME = "Threat_Indicators"

FILE_SHARE_NAME = os.environ.get("File_Share_Name")
FILE_SHARE_NAME_DATA = os.environ.get("File_Share_Name_For_Data")
FILE_NAME_PREFIX = "infoblox_completed"
FAILED_INDICATOR_FILE_PREFIX = "infoblox_failed"

CHUNK_SIZE = 100
MAX_RETRY = 3

FAILED_INDICATORS_TABLE_NAME = "Infoblox_Failed_Indicators"

LOG_FORMAT = "{}(method = {}) : {} : {}"
INDICATOR_FUNCTION_NAME = "ThreatIndicators"
FAILED_INDICATOR_FUNCTION_NAME = "FailedThreatIndicators"
