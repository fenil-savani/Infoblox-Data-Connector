"""This file contains all constants."""

import os

AZURE_CLIENT_ID = os.environ.get("Azure_Client_Id", "")
AZURE_CLIENT_SECRET = os.environ.get("Azure_Client_Secret", "")
AZURE_TENANT_ID = os.environ.get("Azure_Tenant_Id", "")
AZURE_AUTHENTICATION_URL = "https://login.microsoftonline.com/{}/oauth2/v2.0/token"
SCHEDULE = os.environ.get("Schedule", "")
LOGS_STARTS_WITH = "Infoblox TIDE"
LOG_LEVEL = "INFO"
UPLOAD_SENTINEL_INDICATORS_URL = "https://sentinelus.azure-api.net/{}/threatintelligence:upload-indicators?api-version=2022-07-01"
# CONNECTION_STRING = os.environ.get("AzureWebJobsStorage", "")
CONNECTION_STRING = os.environ.get("Connection_String", "")
WORKSPACE_KEY = os.environ.get("Workspace_Key", "")
WORKSPACE_ID = os.environ.get("Workspace_Id", "")
THREATS_TABLE_NAME = "Threat_Host"
# FILE_SHARE_NAME = "infoblox-data-2"
FILE_SHARE_NAME = os.environ.get("File_Share_Name_For_Data")
FILE_NAME_PREFIX = "infoblox_completed"
FAILED_INDICATOR_FILE_PREFIX = "infoblox_failed"
AZURE_FUNCTION_NAME = "InfobloxThreatIntelligence"
FAILED_INDICATOR_FUNCTION = "FailedThreatIndicators"
CHUNK_SIZE = 100
MAX_RETRY = 3
FAILED_INDICATORS_TABLE_NAME = "Infoblox_Failed_Indicators"
