import json
import time
from ..Utils.utils import Utils
from ..SharedCode import consts
from ..SharedCode.logger import applogger
from ..SharedCode.sentinel import build_signature, post_data
from ..SharedCode.infoblox_exception import InfobloxException
import inspect


class RetryFailedIndicators(Utils):

    def __init__(self, start):
        """
        Initializes the CreateThreatIndicator object.
             
        Args:
            start(float): The starting time for the retrying failed indicator process.
        """
        Utils.__init__(self)
        self.check_environment_var_exist()
        self.start = start
        self.count = 0
        self.file_name = ""
        self.bearer_token = self.auth_sentinel(consts.FAILED_INDICATOR_FUNCTION)
        applogger.debug(
            "{} : {} : Bearer Token Generated: {}".format(
                consts.LOGS_STARTS_WITH, consts.FAILED_INDICATOR_FUNCTION, self.bearer_token
            )
        )

    def get_failed_indicators_and_retry(self):
        """Get failed indicators data from checkpoint and try creating them again."""

        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info("{} : {} (method : {}), Starting Retrial for Failed Indicators".format(
                consts.LOGS_STARTS_WITH, consts.LOGS_STARTS_WITH, __method_name
            ))

            failed_file_list = self.filter_file_list(consts.FAILED_INDICATOR_FILE_PREFIX)
            if len(failed_file_list) == 0:
                applogger.info(
                    "{} : {} (method : {}), No Failed Indicators found".format(
                        consts.LOGS_STARTS_WITH, consts.FAILED_INDICATOR_FUNCTION, __method_name
                    )
                )
            else:
                for file_item in failed_file_list:
                    if int(time.time()) >= self.start + 540:
                        applogger.info(
                            "Infoblox: 9:00 mins executed hence breaking."
                        )
                        break
                    self.file_name = file_item
                    state_file_obj = self.initialize_state_manager_obj(
                        consts.FAILED_INDICATOR_FUNCTION, file_item
                    )
                    request_body = self.get_json_data(consts.FAILED_INDICATOR_FUNCTION, state_file_obj)
                    self.upload_indicator(consts.FAILED_INDICATOR_FUNCTION, request_body)
                    state_file_obj.delete()
                    applogger.info(
                        "{} : {} (method : {}), File named : {} deleted".format(
                            consts.LOGS_STARTS_WITH, consts.FAILED_INDICATOR_FUNCTION, __method_name, self.file_name
                        )
                    )
        except InfobloxException:
            raise InfobloxException()    
        except Exception as error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, consts.FAILED_INDICATOR_FUNCTION, __method_name, error
                )
            )
            raise InfobloxException()
