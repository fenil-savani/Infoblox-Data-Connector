import inspect
import requests
import time
import json
from ..SharedCode.state_manager import StateManager
from azure.storage.fileshare import ShareDirectoryClient
from azure.core.exceptions import ResourceNotFoundError
from ..SharedCode.infoblox_exception import InfobloxException
from ..SharedCode.logger import applogger
from ..SharedCode import consts
from ..SharedCode.sentinel import post_data


class Utils:
    def __init__(self) -> None:
        """This class contains helper methods."""
        self.log_error = "{} : {}: (method = {}), Error = {}"
        self.bearer_token = self.auth_sentinel(consts.AZURE_FUNCTION_NAME)
        applogger.debug(
            "{} : Bearer Token Generated: {}".format(
                consts.LOGS_STARTS_WITH, self.bearer_token
            )
        )

    def check_environment_var_exist(self):
        """
        A function to check the existence of required environment variables.
        Logs the validation process and completion.

        Raises:
            InfobloxException: Raised if any required field is missing.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            environment_var = [
                {"AzureTenantId": consts.AZURE_TENANT_ID},
                {"AzureClientId": consts.AZURE_CLIENT_ID},
                {"AzureClientSecret": consts.AZURE_CLIENT_SECRET},
                {"AzureAuthURL": consts.AZURE_AUTHENTICATION_URL},
                {"WorkspaceID": consts.WORKSPACE_ID},
                {"WorkspaceKey": consts.WORKSPACE_KEY},
                {"ConnectionString": consts.CONNECTION_STRING},
                {"File_Share_Name": consts.FILE_SHARE_NAME},
                {"Schedule": consts.SCHEDULE},
            ]
            applogger.debug(
                "{} : (method = {}), Validating Environment Variables".format(
                    consts.LOGS_STARTS_WITH, __method_name
                )
            )
            missing_required_field = False
            for i in environment_var:
                key, val = next(iter(i.items()))
                if (val is None) or (val == ""):
                    missing_required_field = True
                    # applogger.error(
                    #     self.log_error.format(
                    #         consts.LOGS_STARTS_WITH,
                    #         __method_name,
                    #         "Environment variable {} is not set".format(key),
                    #     )
                    # )
                    applogger.error(
                        "{} : (method = {}), Environment variable {} is not set".format(
                            consts.LOGS_STARTS_WITH, __method_name, key
                        )
                    )
            if missing_required_field:
                applogger.error(
                    "{} : (method = {}), Validation failed".format(
                        consts.LOGS_STARTS_WITH, __method_name
                    )
                )
                raise InfobloxException()
            applogger.info(
                "{} : (method = {}), Validation Complete".format(
                    consts.LOGS_STARTS_WITH, __method_name
                )
            )
        except Exception as error:
            # applogger.error(
            #     self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, error)
            # )
            applogger.error(
                "{} : (method = {}), Error = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, error
                )
            )
            raise InfobloxException()

    def get_timestamp(self, filename):
        """
        A function to get the timestamp from filename.

        Args:
            filename (str): The name of the file.

        Returns:
            int: The timestamp of the file.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{} (method : {}), Getting file timestamp".format(
                    consts.LOGS_STARTS_WITH, __method_name
                )
            )
            return int(filename.split("_")[5])
        except IndexError as error_message:
            applogger.error(
                "{} (method : {}), Error = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, error_message
                )
            )

    def is_created_before_10_minutes(self, timestamp):
        """
        A function to check if the file is created before 10 minutes ago.

        Args:
            timestamp: An integer representing the timestamp to check.

        Returns:
            bool: True if the file is created before 10 minutes ago, False otherwise.
        """
        __method_name = inspect.currentframe().f_code.co_name
        current_time = int(time.time())
        applogger.debug(
            "{} (method : {}), Checking file timestamp".format(
                consts.LOGS_STARTS_WITH, __method_name
            )
        )
        return current_time - timestamp > 600

    def list_file_names_in_file_share(
        self, parent_dir: ShareDirectoryClient, file_prefix
    ):
        """Get list of file names from directory.

        Args:
            parent_dir (ShareDirectory.from_connection_string): Object of ShareDirectory to perform operations
            on file share.

        Returns:
            list: list of files
        """
        __method_name = inspect.currentframe().f_code.co_name

        try:
            files_list = list(parent_dir.list_directories_and_files(file_prefix))
            file_names = []
            if (len(files_list)) > 0:
                for file in files_list:
                    file_names.append(file["name"])
            return file_names
        except ResourceNotFoundError:
            applogger.error(
                "{}(method={}), No storage directory found.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                )
            )
            return None
        except Exception as error:
            applogger.error(
                "{} (method : {}), Error while getting list of files, Error = {}.".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    error,
                )
            )
            raise InfobloxException()

    def filter_file_list(self, file_prefix):
        """
        A function to filter a list of filenames based on a given file prefix.

        Args:
            file_prefix(str): A string representing the prefix of the filenames to filter.

        Returns:
            list: A list of filenames that are created before 10 minutes ago.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            parent_dir = ShareDirectoryClient.from_connection_string(
                conn_str=consts.CONNECTION_STRING,
                share_name=consts.FILE_SHARE_NAME,
                directory_path="",
            )

            filenames = self.list_file_names_in_file_share(parent_dir, file_prefix)

            sorted_filenames = sorted(filenames, key=lambda x: self.get_timestamp(x))
            applogger.debug(
                "{} (method : {}), Fetching Sorted List of Filenames : {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, sorted_filenames
                )
            )

            # Filter filenames created before 10 minutes
            filtered_filenames = [
                filename
                for filename in sorted_filenames
                if self.is_created_before_10_minutes(self.get_timestamp(filename))
            ]
            applogger.info(
                "{} (method : {}), Fetching List of Filenames created before 10 minutes: {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, filtered_filenames
                )
            )
            return filtered_filenames
        except InfobloxException:
            raise InfobloxException()
        except Exception as error:
            applogger.error(
                "{}(method={}), Error while fetching filenames created before 10 minutes. Error = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, error
                )
            )
            raise InfobloxException()

    def make_rest_call(
        self, url, method, azure_function_name, headers=None, params=None, payload=None
    ):
        """To make rest api calls to MS Sentinel rest api.

        Args:
            url (String): URL of the rest call.
            method (String): HTTP method of rest call. Eg. "GET", etc.
            headers (Dict, optional): headers. Defaults to None.
            params (Dict, optional): parameters. Defaults to None.
            payload (Type : As required by the rest call, optional): body. Defaults to None.

        Returns:
            response : response of the rest call.
        """
        __method_name = inspect.currentframe().f_code.co_name
        response_error_log = "{} : {} (method={}), Url: {}, Status Code : {}: {}"
        try:
            applogger.info(
                "{}(method={}) : {}: Calling url: {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, azure_function_name, url
                )
            )
            response = requests.request(
                method=method, url=url, headers=headers, params=params, data=payload
            )
            if response.status_code >= 200 and response.status_code <= 299:
                applogger.debug(
                    "{} : {} (method={}), Got response from url : {} : Status code : {}".format(
                        consts.LOGS_STARTS_WITH,
                        azure_function_name,
                        __method_name,
                        url,
                        response.status_code,
                    )
                )
            elif response.status_code >= 400 and response.status_code <= 499:
                log_message = "error occurred while calling url."
                applogger.error(
                    response_error_log.format(
                        consts.LOGS_STARTS_WITH,
                        azure_function_name,
                        __method_name,
                        url,
                        response.json(),
                        log_message,
                    )
                )
            elif response.status_code == 500:
                log_message = "Internal Server Error"
                applogger.error(
                    response_error_log.format(
                        consts.LOGS_STARTS_WITH,
                        azure_function_name,
                        __method_name,
                        url,
                        response.status_code,
                        log_message,
                    )
                )
            else:
                log_message = "Unexpected error occurred."
                applogger.error(
                    response_error_log.format(
                        consts.LOGS_STARTS_WITH,
                        azure_function_name,
                        __method_name,
                        url,
                        response.status_code,
                        log_message,
                    )
                )
        except requests.ConnectionError as error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name, error
                )
            )
            raise InfobloxException()
        except requests.HTTPError as error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name, error
                )
            )
            raise InfobloxException()
        except requests.RequestException as error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name, error
                )
            )
            raise InfobloxException()
        except Exception as error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name, error
                )
            )
            raise InfobloxException()
        return response

    def auth_sentinel(self, azure_function_name):
        """To authenticate with microsoft sentinel.

        Args:
            azure_function_name(str): Name of the azure function.

        Returns:
            string: access token.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{} : {} (method={}), Generating microsoft sentinel access token.".format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name
                )
            )
            azure_auth_url = consts.AZURE_AUTHENTICATION_URL.format(
                consts.AZURE_TENANT_ID
            )
            body = {
                "client_id": consts.AZURE_CLIENT_ID,
                "client_secret": consts.AZURE_CLIENT_SECRET,
                "grant_type": "client_credentials",
                "scope": "https://management.azure.com/.default",
            }
            # applogger.debug("Body for Authentication Request : {}".format(body))
            response = self.make_rest_call(
                url=azure_auth_url,
                method="POST",
                azure_function_name=azure_function_name,
                payload=body,
            )
            if response.status_code >= 200 and response.status_code <= 299:
                json_response = response.json()
                if "access_token" not in json_response:
                    applogger.error(
                        "{} : {}(method={}), Access token not found in sentinel api call.".format(
                            consts.LOGS_STARTS_WITH, azure_function_name, __method_name
                        )
                    )
                    raise InfobloxException()
                else:
                    bearer_token = json_response.get("access_token")
                    applogger.info(
                        "{} : {}(method={}), Microsoft sentinel access token generated successfully.".format(
                            consts.LOGS_STARTS_WITH, azure_function_name, __method_name
                        )
                    )
                    applogger.debug(
                        "{} : {}(method={}), url: {}, Status Code({}) Microsoft Sentinel access token generated".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            azure_function_name,
                            azure_auth_url,
                            response.status_code,
                        )
                    )
                    return bearer_token
            else:
                applogger.error(
                    "{} : {}(method={}), Status Code : {}: Error while creating microsoft sentinel access_token."
                    " Error Reason: {}".format(
                        consts.LOGS_STARTS_WITH,
                        azure_function_name,
                        __method_name,
                        response.status_code,
                        response.reason,
                    )
                )
                raise InfobloxException()
        except KeyError as keyerror:
            applogger.error(
                "{} : {} (method={}), KeyError :{}".format(
                    consts.LOGS_STARTS_WITH,
                    azure_function_name,
                    __method_name,
                    keyerror,
                )
            )
            raise InfobloxException()
        except InfobloxException:
            raise InfobloxException()
        except Exception as error:
            applogger.error(
                "{} : {}(method={}), Error generated while getting sentinel access token :{}".format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name, error
                )
            )
            raise InfobloxException()

    def initialize_state_manager_obj(self, azure_function_name, checkpoint_file_name):
        """Create StateManager object for a given filename

        Args:
            checkpoint_file_name (str): Name of the checkpoint file

        Returns:
            StateManager: Object of StateManager

        Raises:
            InfobloxException: Raised if any error occurs.

        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            state_obj = StateManager(
                connection_string=consts.CONNECTION_STRING,
                file_path=checkpoint_file_name,
            )

            applogger.debug(
                "{} : {} (method={}), Object for Checkpoint file named : {} created".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    azure_function_name,
                    checkpoint_file_name,
                )
            )
            return state_obj

        except Exception as error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name, error
                )
            )
            raise InfobloxException()

    def get_json_data(self, azure_function_name, state_file_obj: StateManager):
        """
        A function to get JSON data from the storage file.

        Args:
            state_file_obj (StateManager): Object of StateManager to retrieve data from.

        Returns:
            list: The JSON data retrieved from the storage file.

        Raises:
            json.decoder.JSONDecodeError: If there is an error decoding JSON data.
            InfobloxException: If there is an error while reading the file.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{} : {} (method={}), Fetching data from storage file".format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name
                )
            )
            text = state_file_obj.get(azure_function_name)

            text = json.loads(text)
            applogger.info(
                "{} (method={}) :Length of data from storage file : {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, len(text)
                )
            )

            return text

        except json.decoder.JSONDecodeError as json_error:
            applogger.error(
                "{} : {} (method={}), Error :{}".format(
                    consts.LOGS_STARTS_WITH,
                    azure_function_name,
                    __method_name,
                    json_error,
                )
            )
            raise InfobloxException()
        except Exception as error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name, error
                )
            )
            raise InfobloxException()

    def upload_indicator(
        self,
        azure_function_name,
        indicator_list,
    ):
        """
        A function to upload indicators to microsoft sentinel.

        Args:
            azure_function_name (str): Name of the azure function
            indicator_list (list): List of indicators to be uploaded

        Raises:
            InfobloxException: If an error occurs while uploading indicators.
        """
        __method_name = inspect.currentframe().f_code.co_name

        try:
            applogger.info(
                "{} : {}: (method={}), Uploading Indicators".format(
                    consts.LOGS_STARTS_WITH, azure_function_name, __method_name
                )
            )
            for _ in range(consts.MAX_RETRY):
                upload_indicator_url = consts.UPLOAD_SENTINEL_INDICATORS_URL.format(
                    consts.WORKSPACE_ID
                )
                applogger.info(
                    "{} : {} (method={}), Length of records : {}".format(
                        consts.LOG_LEVEL,
                        azure_function_name,
                        __method_name,
                        len(indicator_list),
                    )
                )
                body = {
                    "sourcesystem": "Infoblox-TIDE-Threats-Custom",
                    "value": indicator_list,
                }
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer {}".format(self.bearer_token),
                }
                response = self.make_rest_call(
                    url=upload_indicator_url,
                    method="POST",
                    azure_function_name=azure_function_name,
                    headers=headers,
                    payload=json.dumps(body),
                )
                applogger.info(
                    "{} : {} (method={}), Rest Call Completed with Status code:{}".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        azure_function_name,
                        response.status_code,
                    )
                )
                if response.status_code >= 200 and response.status_code <= 299:
                    applogger.info(
                        "{} : {} (method={}), Indicators validated and published with status code: {}.".format(
                            consts.LOGS_STARTS_WITH,
                            azure_function_name,
                            __method_name,
                            response.status_code,
                        )
                    )
                    applogger.info(
                        "{} : {} (method={}), Checking for error".format(
                            consts.LOGS_STARTS_WITH, azure_function_name, __method_name
                        )
                    )
                    response_json = response.json()

                    if len(response_json.get("errors")) == 0:
                        applogger.info(
                            "{} : {} (method={}), No error in Response".format(
                                consts.LOGS_STARTS_WITH,
                                azure_function_name,
                                __method_name,
                            )
                        )
                    else:
                        record_indexes = [
                            error.get("recordIndex")
                            for error in response_json["errors"]
                        ]
                        failed_indicators = [
                            indicator_list[index] for index in record_indexes
                        ]
                        # LOGIC TO WRITE FAILED INDICATORS IN NEW FILE
                        if len(failed_indicators) != 0:
                            if azure_function_name == consts.AZURE_FUNCTION_NAME:
                                applogger.info(
                                    "{} : {} (method={}), Writing Failed Indicators to new file.".format(
                                        consts.LOGS_STARTS_WITH,
                                        azure_function_name,
                                        __method_name,
                                    )
                                )
                                file_timestamp = time.time()
                                failed_file_name = (
                                    "infoblox_tide_failed_indicators_file_{}".format(
                                        str(int(file_timestamp))
                                    )
                                )
                                failed_indicator_file = (
                                    self.initialize_state_manager_obj(
                                        azure_function_name, failed_file_name
                                    )
                                )
                                failed_indicator_file.post(
                                    json.dumps(failed_indicators)
                                )
                            else:
                                applogger.info(
                                    "{} : {} (method={}), Ingesting Failed Indicators to Log Table.".format(
                                        consts.LOGS_STARTS_WITH,
                                        azure_function_name,
                                        __method_name,
                                    )
                                )
                                post_data(
                                    body=json.dumps(failed_indicators),
                                    log_type=consts.FAILED_INDICATORS_TABLE_NAME,
                                )
                    applogger.debug(
                        "{} : {} (method={}), Response Text from Upload Indicator API : {}".format(
                            consts.LOGS_STARTS_WITH,
                            azure_function_name,
                            __method_name,
                            response.text,
                        )
                    )
                    return None
                elif response.status_code == 400:
                    json_response = response.json()
                    applogger.warning(
                        "{} : {} (method={}), Url: {}, Status Code : {}: Error while\
                                creating Indicators, Error:{}.".format(
                            consts.LOGS_STARTS_WITH,
                            azure_function_name,
                            __method_name,
                            upload_indicator_url,
                            response.status_code,
                            json_response,
                        )
                    )
                elif response.status == 401:
                    applogger.error(
                        "{} : {} (method={}), Unauthorized, Invalid Credentials, Trying again error-401.".format(
                            consts.LOGS_STARTS_WITH, azure_function_name, __method_name
                        )
                    )
                    self.bearer_token = self.auth_sentinel("Infoblox TIDE")
                    headers["Authorization"] = "Bearer {}".format(self.bearer_token)
                    continue
                else:
                    applogger.error(
                        "{} : {} (method={}), Error while creating indicators, status_code: {}.".format(
                            consts.LOGS_STARTS_WITH,
                            azure_function_name,
                            __method_name,
                            response.status_code,
                        )
                    )
        except KeyError as keyerror:
            applogger.error(
                "{} : {} (method={}), KeyError :{}".format(
                    consts.LOGS_STARTS_WITH,
                    azure_function_name,
                    __method_name,
                    keyerror,
                )
            )
            raise InfobloxException()
        except InfobloxException:
            raise InfobloxException()
        except Exception as error:
            applogger.error(
                "{} : {} (method={}), Error generated while Uploading Indicator :{}".format(
                    consts.LOGS_STARTS_WITH, __method_name, azure_function_name, error
                )
            )
            raise InfobloxException()
