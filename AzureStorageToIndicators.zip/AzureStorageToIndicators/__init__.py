import datetime
import time
import logging
import azure.functions as func
from .create_indicator import CreateThreatIndicator
from .indicator_mapping import Mapping
from ..SharedCode.logger import applogger
from ..SharedCode import consts


def main(mytimer: func.TimerRequest) -> None:
    """Driver method for Infoblox to sentinel."""

    utc_timestamp = (
        datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc).isoformat()
    )
    start = time.time()
    applogger.info("{} : Starting Infoblox Execution".format(consts.LOGS_STARTS_WITH))
    indicator_obj = CreateThreatIndicator(start)
    indicator_obj.parse_file_list()
    if mytimer.past_due:
        logging.info("The timer is past due!")

    logging.info("Python timer trigger function ran at %s", utc_timestamp)
