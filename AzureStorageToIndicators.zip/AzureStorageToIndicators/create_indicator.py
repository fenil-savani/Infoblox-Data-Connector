import inspect
import time
from ..SharedCode import consts
from ..SharedCode.infoblox_exception import InfobloxException
from ..SharedCode.logger import applogger
from .indicator_mapping import Mapping
from ..SharedCode.state_manager import StateManager
from ..Utils.utils import Utils


class CreateThreatIndicator(Utils):

    def __init__(self, start):
        """
        Initializes the CreateThreatIndicator object.

        Args:
            start(float): The starting time for the indicator creation process.
        """
        Utils.__init__(self)
        self.check_environment_var_exist()
        self.mapping_obj = Mapping()
        self.count_state_obj = StateManager(
            connection_string=consts.CONNECTION_STRING, file_path="indicator_count"
        )
        self.start = start
        self.count = 0
        self.file_name = ""

    def save_checkpoint(self, file_name, record_count):
        """Save data to checkpoint file.

        Args:
            file_name (_type_): File name to be saved to checkpoint file.
            record_count (_type_): Count of Indicators to be saved to checkpoint file.

        Raises:
            InfobloxException: Raised if any error occurs while saving checkpoint data
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{} (method : {}), Indicator Count to post to Checkpoint file : {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, record_count
                )
            )
            self.count_state_obj.post(file_name + "," + str(record_count))
        except TypeError as type_error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH,
                    consts.AZURE_FUNCTION_NAME,
                    __method_name,
                    type_error,
                )
            )
            raise InfobloxException()
        except Exception as error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH,
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    error,
                )
            )
            raise InfobloxException()

    def parse_file_list(self):
        """Get list of file names and upload indicators to Sentinel.

        Raises:
            InfobloxException: Raised if any error occurs while fetching data from file and uploading indicators.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            file_list = self.filter_file_list(consts.FILE_NAME_PREFIX)
            for file_item in file_list:
                if int(time.time()) >= self.start + 540:
                    applogger.info("Infoblox: 9:00 mins executed hence breaking.")
                    break
                self.file_name = file_item
                state_file_obj = self.initialize_state_manager_obj(
                    consts.AZURE_FUNCTION_NAME, file_item
                )
                request_body = self.get_json_data(
                    consts.AZURE_FUNCTION_NAME, state_file_obj
                )

                checkpoint_file_count = self.count_state_obj.get(
                    consts.AZURE_FUNCTION_NAME
                )
                if checkpoint_file_count is None or checkpoint_file_count == "":
                    self.count = 0
                else:
                    self.count = int(checkpoint_file_count.split(",")[1])
                applogger.info(
                    "{} : {} (method : {}) Indicator Count from Checkpoint : {}".format(
                        consts.LOGS_STARTS_WITH,
                        consts.AZURE_FUNCTION_NAME,
                        __method_name,
                        self.count,
                    )
                )

                chunked_data = self.mapping_obj.create_chunks(request_body, self.count)
                save_checkpoint_flag = True
                start_time = time.time()
                index = 0
                for chunk in chunked_data:
                    if int(time.time()) >= self.start + 540:
                        applogger.info("Infoblox: 9:00 mins executed hence breaking.")
                        save_checkpoint_flag = False
                        break

                    mapped_data = self.mapping_obj.map_threat_data(chunk)
                    applogger.info(
                        "{} : {} (method : {}), File name = {}, Ingesting {} Indicators, index = {}".format(
                            consts.LOGS_STARTS_WITH,
                            consts.AZURE_FUNCTION_NAME,
                            __method_name,
                            file_item,
                            len(mapped_data),
                            index,
                        )
                    )
                    self.upload_indicator(consts.AZURE_FUNCTION_NAME, mapped_data)
                    self.count += len(mapped_data)
                    self.save_checkpoint(self.file_name, self.count)
                    index += 1
                end_time = time.time()
                applogger.info(
                    "{} : {} (method : {}), Time taken to upload Indicators for file : {} = {}".format(
                        consts.LOGS_STARTS_WITH,
                        consts.AZURE_FUNCTION_NAME,
                        __method_name,
                        file_item,
                        (end_time - start_time),
                    )
                )
                if save_checkpoint_flag:
                    self.count_state_obj.post("")
                    state_file_obj.delete()
                    applogger.info(
                        "{} : {} (method : {}), File named {} deleted".format(
                            consts.LOGS_STARTS_WITH,
                            consts.AZURE_FUNCTION_NAME,
                            __method_name,
                            self.file_name,
                        )
                    )
        except InfobloxException:
            raise InfobloxException()
        except Exception as error:
            applogger.error(
                "{} : {} (method={}), Error while parsing File list :{}".format(
                    consts.LOGS_STARTS_WITH,
                    consts.AZURE_FUNCTION_NAME,
                    __method_name,
                    error,
                )
            )
            raise InfobloxException()
