import requests
import inspect
from ..SharedCode.state_manager import StateManager
from ..SharedCode import consts
from ..SharedCode.logger import applogger
# from ..SharedCode.sentinel import build_signature, post_data
# from ..TIDE import get_logs_data
import json
from ..SharedCode.infoblox_exception import InfobloxException


class Mapping:
    def __init__(self):
        """Initialize instance variable for class."""
        # self.state_obj = StateManager(
        #     connection_string=consts.CONNECTION_STRING,
        #     file_path="ipthreats.json",
        # )
        # applogger.info("STATE MANAGER")
        pass

    # def initialize_state_manager_obj(self, checkpoint_file_name):
    #     __method_name = inspect.currentframe().f_code.co_name
    #     try:
    #         # self.state_obj = StateManager(
    #         #     connection_string=consts.CONNECTION_STRING, file_path=checkpoint_file_name
    #         # )
    #         state_obj = StateManager(
    #             connection_string=consts.CONNECTION_STRING,
    #             file_path=checkpoint_file_name,
    #         )

    #         applogger.debug(
    #             "Object for Checkpoint file named : {} created".format(checkpoint_file_name)
    #         )
    #         return state_obj

    #     except InfobloxException as error:
    #         applogger.error(
    #             "{}(method={}) : Error while parsing File list :{}".format(
    #                 consts.LOGS_STARTS_WITH, __method_name, error
    #             )
    #         )
    #         raise InfobloxException()

    def map_threat_data(self, text):
        """
        A method to map threat data to the required format for processing.

        Args:
            text (list): A list of threat data items to be processed.

        Returns:
            list: A list of mapped threat data items in the required format.
        """

        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info("{} :{} (method={}), Mapping threat data".format(
                consts.LOGS_STARTS_WITH, consts.LOGS_STARTS_WITH, __method_name
            ))
            mapped = []
            temp = {
                "HOST": "[domain-name:value = {}]",
                "IP": "[ipv4-addr:value = {}]",
                "URL": "[url:value = {}]",
                "HASH": "[file:value = {}]",
            }
            for item in text:
                body = {
                    "type": "indicator",
                    "spec_version": "2.1",
                    "id": "indicator--{}".format(item.get("id")),
                    "created": item.get("detected"),
                    "modified": item.get("detected"),
                    "revoked": item.get("up", False),
                    "labels": [
                        item.get("type"),
                        "Imported : {}".format(item.get("imported")),
                        "Profile : {}".format(item.get("profile")),
                        "Property : {}".format(item.get("property")),
                        "Threat Level : {}".format(item.get("threat_level")),
                    ],
                    "confidence": (
                        item.get("confidence")
                        if item.get("confidence")
                        else item.get("threat_level", 50)
                    ),
                    "description": "Infoblox - {} - {}".format(
                        item.get("type"), item.get("class")
                    ),
                    "indicator_types": [item.get("class")],
                    "pattern": temp.get(item.get("type")).format(
                        item.get(item.get("type").lower())
                    ),
                    "pattern_type": "stix",
                    "pattern_version": "2.1",
                    "valid_from": item.get("received"),
                    "valid_until": item.get("expiration"),
                }
                # if item.get("type") == "HOST":
                #     body["pattern"] = "[domain-name:value = {}]".format(item.get("host"))
                # elif item.get("type") == "IP":
                #     body["pattern"] = "[ipv4-addr:value = {}]".format(item.get("ip"))
                # elif item.get("type") == "URL":
                #     body["pattern"] = "[url:value = {}]".format(item.get("url"))
                # elif item.get("type") == "HASH":
                #     body["pattern"] = "[file:value = {}]".format(item.get("hash"))

                # indicator_id_obj = {"ID": item.get("id"), "DomainName": item.get("domain")}
                # indicator_id_list.append(indicator_id_obj)
                mapped.append(body)
            return mapped

        except KeyError as keyerror:
            applogger.error(
                "{} : {} (method={}), KeyError while mapping threat data :{}".format(
                    consts.LOGS_STARTS_WITH, consts.AZURE_FUNCTION_NAME, __method_name, keyerror
                )
            )
            raise InfobloxException()
        except Exception as error:
            applogger.error(
                "{} : {} (method={}), Error while mapping threat data :{}".format(
                    consts.LOGS_STARTS_WITH, consts.AZURE_FUNCTION_NAME, __method_name, error
                )
            )
            raise InfobloxException()

    def create_chunks(self, text, start_index):
        """
        A method to create chunks from the input text starting at a specific index.

        Args:
            text (str): The input text from which chunks will be created.
            start_index (int): The starting index to begin creating chunks from.

        Returns:
            list: A list of chunked data items.

        Raises:
            InfobloxException: If an error occurs while breaking the data into chunks.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info("{} : {} (method={}), Creating Chunks".format(
                consts.LOGS_STARTS_WITH, consts.AZURE_FUNCTION_NAME, __method_name
            ))
            chunk_size = consts.CHUNK_SIZE
            chunked_data = [
                text[index: index + chunk_size]
                for index in range(start_index, len(text), chunk_size)
            ]
            applogger.debug(
                "{} (method={}) : Number of chunks : {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, len(chunked_data)
                )
            )

            return chunked_data
        except Exception as error:
            applogger.error(
                "{} : {} (method={}), Error while breaking data into chunks :{}".format(
                    consts.LOGS_STARTS_WITH, consts.AZURE_FUNCTION_NAME, __method_name, error
                )
            )
            raise InfobloxException()

    # def create_chunks(self, text):
    #     chunk_size = 100
    #     mapped_updated = [
    #         text[index: index + chunk_size]
    #         for index in range(0, len(text), chunk_size)
    #     ]
    #     applogger.info("LENGTH : {}".format(len(mapped_updated)))
    #     return mapped_updated

    # def get_json_data(self, state_file_obj: StateManager):
    #     __method_name = inspect.currentframe().f_code.co_name
    #     try:
    #         # text = self.state_obj.get("TIDE")
    #         applogger.info("{} (method={}) :Fetching data from storage file".format(consts.LOGS_STARTS_WITH, __method_name))
    #         text = state_file_obj.get("TIDE")

    #         text = json.loads(text)
    #         applogger.info(
    #             "{} (method={}) :Length of data from storage file : {}".format(
    #                 consts.LOGS_STARTS_WITH, __method_name, len(text)
    #             )
    #         )

    #         return text

    #     except json.decoder.JSONDecodeError as json_error:
    #         applogger.error(
    #             "{}(method={}) : Error :{}".format(
    #                 consts.LOGS_STARTS_WITH, __method_name, json_error
    #             )
    #         )
    #         raise InfobloxException()
    #     except Exception as error:
    #         applogger.error(
    #             "{}(method={}) : Error while reading File :{}".format(
    #                 consts.LOGS_STARTS_WITH, __method_name, error
    #             )
    #         )
    #         raise InfobloxException()

    # indicator_id_list = []
    # mapped = []
    # temp = {
    #     "HOST": "[domain-name:value = {}]",
    #     "IP": "[ipv4-addr:value = {}]",
    #     "URL": "[url:value = {}]",
    #     "HASH": "[file:value = {}]",
    # }
    # chunk_size = 100

    # for item in text:
    #     body = {
    #         "type": "indicator",
    #         "spec_version": "2.1",
    #         "id": "indicator--{}".format(item.get("id")),
    #         "created": item.get("detected"),
    #         "modified": item.get("detected"),
    #         "revoked": item.get("up", False),
    #         "labels": [
    #             item.get("type"),
    #             "Imported : {}".format(item.get("imported")),
    #             "Profile : {}".format(item.get("profile")),
    #             "Property : {}".format(item.get("property")),
    #             "Threat Level : {}".format(item.get("threat_level")),
    #         ],
    #         "confidence": (
    #             item.get("confidence")
    #             if item.get("confidence")
    #             else item.get("threat_level", 50)
    #         ),
    #         "description": "Infoblox - {} - {}".format(
    #             item.get("type"), item.get("class")
    #         ),
    #         "indicator_types": [item.get("class")],
    #         "pattern": temp.get(item.get("type")).format(
    #             item.get(item.get("type").lower())
    #         ),
    #         "pattern_type": "stix",
    #         "pattern_version": "2.1",
    #         "valid_from": item.get("received"),
    #         "valid_until": item.get("expiration"),
    #     }
    #     # if item.get("type") == "HOST":
    #     #     body["pattern"] = "[domain-name:value = {}]".format(item.get("host"))
    #     # elif item.get("type") == "IP":
    #     #     body["pattern"] = "[ipv4-addr:value = {}]".format(item.get("ip"))
    #     # elif item.get("type") == "URL":
    #     #     body["pattern"] = "[url:value = {}]".format(item.get("url"))
    #     # elif item.get("type") == "HASH":
    #     #     body["pattern"] = "[file:value = {}]".format(item.get("hash"))

    #     indicator_id_obj = {"ID": item.get("id"), "DomainName": item.get("domain")}
    #     indicator_id_list.append(indicator_id_obj)
    #     mapped.append(body)

    # applogger.info("MAPPING: {}".format(mapped[0]))
    # mapped_updated = [
    #     mapped[i : i + chunk_size] for i in range(0, len(mapped), chunk_size)
    # ]
    # print("LENGTH : {}".format(len(mapped_updated)))
    # return mapped_updated
    # list1 = [
    #     {
    #         "type": "indicator",
    #         "spec_version": "2.1",
    #         "id": "indicator--a567a399-a46c-11ee-8f07-6f3d6979394d",
    #         "name": "Test Indicator 23April",
    #         "created": "2010-02-26T18:29:07.778Z",
    #         "modified": "2011-02-26T18:29:07.778Z",
    #         "pattern": "[ipv4-addr:value = '192.0.3.110']",
    #         "pattern_type": "stix",
    #         "valid_from": "2015-02-26T18:29:07.778Z",
    #     },
    # ]
    # return list1

    # applogger.debug("LIST : {}".format(indicator_id_list))
    # logs_host_data = get_logs_data()
    # # Get list of domains from logs_data
    # log_domain_list = [host["DomainName_s"] for host in logs_host_data]
    # applogger.info("List of Domains in Logs Table : {}".format(log_domain_list))

    # remaining_domains = [
    #     item
    #     for item in indicator_id_list
    #     if item["DomainName_s"] not in log_domain_list
    # ]
    # applogger.info(
    #     "Threats for which Indicators are not created(not present in Logs): {}".format(
    #         remaining_domains
    #     )
    # )
    # # Create Indicators for remaining domains list

    # # data_to_post = json.dumps(indicator_id_list)

    # # data_to_post = json.dumps(remaining_domains)
    # # post_data(data_to_post, consts.THREATS_TABLE_NAME)
    # # applogger.info("Data posted successfully")
    # # domain_string = ", ".join(
    # #     ["'{}'".format(item["DomainName"]) for item in indicator_id_list]
    # # )
    # # applogger.info(domain_string)

    # # return mapped, domain_string
