"""Module with constants and configurations for the Infoblox integration."""

import os

# *Infoblox related constants
BASE_URL = "https://csp.infoblox.com{}"
ENDPOINTS = {
    "threats": "/tide/api/data/threats",
    "threats_by_type": "/tide/api/data/threats/{}",
    "active_threats_by_type": "/tide/api/data/threats/state/{}",
}
MAX_FILE_SIZE = 20 * 1024 * 1024
MAX_CHUNK_SIZE = 1024 * 1024
TIME_INTERVAL = -6

# *Sentinel related constants
CONN_STRING = os.environ.get("Connection_String")
FILE_SHARE_NAME_DATA = os.environ.get("File_Share_Name_For_Data")
MAX_RETRIES = 3

# *Extra constants, use for code readability
LOGS_STARTS_WITH = "Infoblox"

# *ParseRawIndicatorsData
INFOBLOX_PARSE_RAW_JSON_DATA = "InfoBloxParseRawJsonData"
FILE_NAME_PREFIX = "infoblox_raw"
ONE_HOUR_EPOCH_VALUE = 3600
