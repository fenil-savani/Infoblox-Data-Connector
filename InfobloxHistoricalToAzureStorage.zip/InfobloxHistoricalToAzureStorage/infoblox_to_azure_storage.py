import inspect
import datetime
from azure.storage.fileshare import ShareDirectoryClient
from ..SharedCode import consts
from ..SharedCode.infoblox_exception import InfobloxException
from ..SharedCode.logger import applogger
from ..SharedCode.state_manager import StateManager
from ..SharedCode.utils import Utils


class InfobloxToAzureStorage(Utils):
    """Class for storing the data from infoblox to azure storage"""

    def __init__(self, start_time) -> None:
        """Initialize InfobloxToAzureStorage object."""
        super().__init__()
        self.start_time = start_time
        self.ioc_type = consts.TYPE
        self.check_environment_var_exist()
        self.authenticate_infoblox_api()
        self.parent_file = ShareDirectoryClient.from_connection_string(
            conn_str=consts.CONN_STRING,
            share_name=consts.FILE_SHARE_NAME_DATA,
            directory_path="",
        )

    def get_infoblox_data_into_azure_storage(self) -> None:
        """Get infoblox data and send the data to azure storage, initialization method."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint_file_name = consts.FILE_NAME + "-" + self.ioc_type
            date_state_manager_obj = StateManager(
                consts.CONN_STRING, checkpoint_file_name, consts.FILE_SHARE_NAME
            )
            self.initiate_and_iterate_through_response_obj(date_state_manager_obj)

        except InfobloxException:
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def initiate_and_iterate_through_response_obj(self, date_state_manager_obj):
        """Initiates and iterates through the response object.
        Fetches checkpoint data, processes dates, and query parameters.
        Handles response object iteration and posts data to Azure storage.

        Args:
            date_state_manager_obj: State management object.

        Returns:
            None

        Raises:
            InfobloxException: When an Infoblox related exception occurs.
            Exception: When any other exception occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{}:(method = {}), Fetching checkpoint data".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                )
            )
            checkpoint_data = self.get_checkpoint_data(
                date_state_manager_obj, load_flag=True
            )
            to_date = None
            if checkpoint_data:
                to_date = checkpoint_data.get("from_date", None)

            if (to_date is None) or (to_date == ""):
                to_date = datetime.datetime.now(datetime.timezone.utc).strftime(
                    "%Y-%m-%d %H:%M:%S.%f"
                )[:-3]
                data_to_post = {"from_date": to_date}
                self.post_checkpoint_data(
                    date_state_manager_obj, data_to_post, dump_flag=True
                )

            from_date = self.add_xh_to_iso_time_string(to_date, consts.TIME_INTERVAL)

            base_checkpoint_file_name_for_from_and_to_dates = (
                self.create_checkpoint_file_name_using_dates(
                    from_date, to_date, self.ioc_type
                )
            )

            self.checkpoint_for_from_and_to_dates = StateManager(
                consts.CONN_STRING,
                base_checkpoint_file_name_for_from_and_to_dates,
                consts.FILE_SHARE_NAME_DATA,
            )
            status_of_last_from_to = self.get_checkpoint_data(
                self.checkpoint_for_from_and_to_dates
            )

            if status_of_last_from_to:
                status_of_last_from_to = int(status_of_last_from_to)
                applogger.info(
                    "{}:(method = {}), status_of_last_from_to = {}".format(
                        consts.LOGS_STARTS_WITH, __method_name, status_of_last_from_to
                    )
                )
                list_of_file_with_prefix = self.list_file_names_in_file_share(
                    self.parent_file,
                    base_checkpoint_file_name_for_from_and_to_dates,
                )
                applogger.info(
                    "{}:(method = {}), No. of file = {} with prefix = {}".format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        len(list_of_file_with_prefix),
                        base_checkpoint_file_name_for_from_and_to_dates,
                    )
                )
                # ! delete all checkpoints file starting with prefix base_checkpoint_file_name_for_from_and_to_dates
                if list_of_file_with_prefix:
                    self.delete_files_from_azure_storage(
                        list_of_file_with_prefix, self.parent_file
                    )
                if status_of_last_from_to > 2:
                    self.store_failed_range_in_state_manager(from_date, to_date)

                    to_date = from_date
                    from_date = self.add_xh_to_iso_time_string(
                        to_date, consts.TIME_INTERVAL
                    )
                    base_checkpoint_file_name_for_from_and_to_dates = (
                        self.create_checkpoint_file_name_using_dates(
                            from_date, to_date, self.ioc_type
                        )
                    )
                    data_to_post = {"from_date": to_date}
                    self.post_checkpoint_data(
                        date_state_manager_obj, data_to_post, dump_flag=True
                    )
                    self.checkpoint_for_from_and_to_dates = StateManager(
                        consts.CONN_STRING,
                        base_checkpoint_file_name_for_from_and_to_dates,
                        consts.FILE_SHARE_NAME_DATA,
                    )
                    status_of_last_from_to = 1
                    self.post_checkpoint_data(
                        self.checkpoint_for_from_and_to_dates,
                        str(status_of_last_from_to),
                    )
                else:
                    status_of_last_from_to += 1
                    self.post_checkpoint_data(
                        self.checkpoint_for_from_and_to_dates,
                        str(status_of_last_from_to),
                    )
            else:
                status_of_last_from_to = 1
                applogger.info(
                    "{}:(method = {}), status_of_last_from_to = {}".format(
                        consts.LOGS_STARTS_WITH, __method_name, status_of_last_from_to
                    )
                )
                self.post_checkpoint_data(
                    self.checkpoint_for_from_and_to_dates, str(status_of_last_from_to)
                )

            query_params = {"from_date": from_date, "to_date": to_date}

            applogger.info(
                "{}:(method = {}), Query params = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, query_params
                )
            )

            response_obj = self.initiate_response_obj(query_params, self.ioc_type)

            base_checkpoint_file_name_for_from_and_to_dates += "_" + self.start_time
            # ! iterate through the response object
            self.iterate_through_response_obj(
                response_obj, base_checkpoint_file_name_for_from_and_to_dates
            )
            applogger.info(
                "{}:(method = {}), IOCs posted to azure storage from_date = {} to_date = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, from_date, to_date
                )
            )
            data_to_post = {"from_date": from_date}
            self.post_checkpoint_data(
                date_state_manager_obj, data_to_post, dump_flag=True
            )

            self.checkpoint_for_from_and_to_dates.delete()
        except InfobloxException:
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def initiate_response_obj(self, query_params, ioc_type):
        """Initiates the response object by building the URL based on the endpoint and IOC type,
        then sends a request to get the Infoblox stream response object using the given query parameters.

        Args:
            query_params: A dictionary containing query parameters.
            ioc_type: The type of IOC (Indicator of Compromise).

        Returns:
            The response object obtained from Infoblox.

        Raises:
            InfobloxException: When an Infoblox related exception occurs.
            Exception: When any other exception occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            endpoint = consts.ENDPOINTS["active_threats_by_type"]
            url = self.url_builder(endpoint, ioc_type)
            applogger.info(
                "{}:(method = {}), url = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, url
                )
            )
            response_obj = self.get_infoblox_stream_response_obj(
                url, query_parameters=query_params
            )

            return response_obj
        except InfobloxException:
            raise InfobloxException()
        except KeyError as key_error:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, key_error)
            )
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def create_checkpoint_file_name_using_dates(self, from_date, to_date, ioc_type):
        """Creates a checkpoint file name using the specified from_date, to_date, and IOC type.

        Args:
            from_date: The starting date for the checkpoint.
            to_date: The ending date for the checkpoint.
            ioc_type: The type of IOC (Indicator of Compromise).

        Returns:
            The generated checkpoint file name.

        Raises:
            InfobloxException: If an Infoblox related exception occurs.
            Exception: If any other exception happens.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            from_epoch = self.iso_to_epoch_str(from_date)
            to_epoch = self.iso_to_epoch_str(to_date)

            checkpoint_file_name = "infoblox_raw_{}_{}_{}".format(
                ioc_type, from_epoch, to_epoch
            )
            applogger.info(
                "{}:(method = {}), checkpoint_file_name = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, checkpoint_file_name
                )
            )
            return checkpoint_file_name
        except InfobloxException:
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def iterate_through_response_obj(
        self, response_obj, base_checkpoint_file_name_for_from_and_to_dates
    ):
        """Iterates through the response object, processes the data in chunks, and sends it to Azure storage.

        Args:
            response_obj: The response object to iterate through.
            base_checkpoint_file_name_for_from_and_to_dates: The base name for the checkpoint data file.

        Returns:
            None

        Raises:
            InfobloxException: When an Infoblox related exception occurs.
            Exception: When any other exception occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            response_data = None
            max_file_size = consts.MAX_FILE_SIZE
            max_chunk_size = consts.MAX_CHUNK_SIZE
            index = 1
            for chunk in response_obj.iter_content(max_chunk_size):
                if chunk is None:
                    break
                chunk_len = len(chunk)
                if response_data is None:
                    response_data = chunk
                elif (len(response_data) + chunk_len) > max_file_size:
                    applogger.info(
                        "{}:(method = {}), Index = {}, Len = {}, Max File Size = {}, Sending data to storage".format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            index,
                            len(response_data),
                            max_file_size,
                        )
                    )
                    self.send_to_azure_storage(
                        response_data,
                        base_checkpoint_file_name_for_from_and_to_dates,
                        index,
                    )
                    index += 1
                    response_data = chunk
                else:
                    response_data += chunk
            if response_data:
                self.send_to_azure_storage(
                    response_data,
                    base_checkpoint_file_name_for_from_and_to_dates,
                    index,
                )
        except InfobloxException:
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def send_to_azure_storage(
        self, response_data, base_checkpoint_file_name_for_from_and_to_dates, index
    ):
        """Sends response data to Azure storage.

        Args:
            response_data: The data to be sent to Azure storage.
            base_checkpoint_file_name_for_from_and_to_dates: The base file name for the checkpoint data.
            index: The index of the data being sent.

        Returns:
            None

        Raises:
            InfobloxException: If an Infoblox related exception occurs.
            Exception: If any other exception occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{}:(method = {}), Index = {}, Checkpoint File Name = {}, Sending data...".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    index,
                    base_checkpoint_file_name_for_from_and_to_dates + "_" + str(index),
                )
            )
            checkpoint_obj = StateManager(
                consts.CONN_STRING,
                base_checkpoint_file_name_for_from_and_to_dates + "_" + str(index),
                consts.FILE_SHARE_NAME_DATA,
            )
            self.post_checkpoint_data(checkpoint_obj, response_data)
        except InfobloxException:
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()
