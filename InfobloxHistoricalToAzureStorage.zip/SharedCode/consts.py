"""Module with constants and configurations for the Infoblox integration."""

import os

# *Infoblox related constants
API_TOKEN = os.environ.get("API_token")
BASE_URL = "https://csp.infoblox.com{}"
ENDPOINTS = {
    "threats": "/tide/api/data/threats",
    "threats_by_type": "/tide/api/data/threats/{}",
    "active_threats_by_type": "/tide/api/data/threats/state/{}",
}
MAX_FILE_SIZE = 20 * 1024 * 1024
MAX_CHUNK_SIZE = 1024 * 1024
TIME_INTERVAL = int(os.environ.get("TIME_INTERVAL"))
TYPE = os.environ.get("ThreatType")
FIELDS = "id,type,ip,url,tld,email,hash,hash_type,host,domain,profile,property,class,threat_level,confidence,detected,received,imported,expiration,dga,up,threat_score,threat_score_rating,confidence_score,confidence_score_rating,risk_score,risk_score_rating,extended"

# *Sentinel related constants
CONN_STRING = os.environ.get("Connection_String")
FILE_SHARE_NAME = os.environ.get("File_Share_Name")
FILE_NAME = os.environ.get("Checkpoint_File_Name")
FILE_SHARE_NAME_DATA = os.environ.get("File_Share_Name_For_Data")
MAX_RETRIES = 3

# *Extra constants, use for code readability
LOGS_STARTS_WITH = "Infoblox"
AZURE_FUNCTION_NAME = "Historical Data"
