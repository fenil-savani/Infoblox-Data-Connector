import inspect
import json
import requests
import datetime
from azure.storage.fileshare import ShareDirectoryClient
from azure.core.exceptions import ResourceNotFoundError
from .logger import applogger
from .state_manager import StateManager
from .infoblox_exception import InfobloxException
from . import consts


class Utils:
    def __init__(self):
        self.log_error = "{}:(method = {}), error = {}"
        self.headers = {}

    def check_environment_var_exist(self):
        """A function to check the existence of required environment variables.
        Logs the validation process and completion. Raises InfobloxException if any required field is missing.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            environment_var = [
                {"Api_Token": consts.API_TOKEN},
                {"File_Share_Name": consts.FILE_SHARE_NAME},
                {"File_Name": consts.FILE_NAME},
            ]
            applogger.debug(
                "{}:(method = {}), Validating Environment Variables".format(
                    consts.LOGS_STARTS_WITH, __method_name
                )
            )
            missing_required_field = False
            for i in environment_var:
                key, val = next(iter(i.items()))
                if (val is None) or (val == ""):
                    missing_required_field = True
                    applogger.error(
                        self.log_error.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            "Environment variable {} is not set".format(key),
                        )
                    )
            if missing_required_field:
                applogger.error(
                    "{}:(method = {}), Validation failed".format(
                        consts.LOGS_STARTS_WITH, __method_name
                    )
                )
                raise InfobloxException()
            applogger.info(
                "{}:(method = {}), Validation Complete".format(
                    consts.LOGS_STARTS_WITH, __method_name
                )
            )
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def get_checkpoint_data(self, checkpoint_obj: StateManager, load_flag=False):
        """A function to get checkpoint data from a StateManager object.
        It retrieves the checkpoint data and logs it if the load flag is set to True.

        Args:
            checkpoint_obj (StateManager): The StateManager object to retrieve checkpoint data from.
            load_flag (bool): A flag indicating whether to load the data as JSON (default is False).

        Returns:
            The retrieved checkpoint data.

        Raises:
            InfobloxException: When an Infoblox related exception occurs.
            Exception: When any other exception occurs.

        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint_data = checkpoint_obj.get()
            if load_flag and checkpoint_data:
                checkpoint_data = json.loads(checkpoint_data)
                applogger.info(
                    "{}:(method = {}), Checkpoint Data = {}".format(
                        consts.LOGS_STARTS_WITH, __method_name, checkpoint_data
                    )
                )
                return checkpoint_data
            applogger.info(
                "{}:(method = {}), Checkpoint Data = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, checkpoint_data
                )
            )
            return checkpoint_data
        except json.decoder.JSONDecodeError as json_error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, __method_name, json_error
                )
            )
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def post_checkpoint_data(self, checkpoint_obj: StateManager, data, dump_flag=False):
        """A function to post checkpoint data.
        It posts the data to a checkpoint object based on the dump_flag parameter.

        Args:
            checkpoint_obj (StateManager): The StateManager object to post data to.
            data: The data to be posted.
            dump_flag (bool): A flag indicating whether to dump the data as JSON before posting (default is False).

        Raises:
            TypeError: When a type error occurs.
            Exception: When any other exception occurs.
            InfobloxException: When an Infoblox related exception occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if dump_flag:
                applogger.info(
                    "{}:(method = {}), Data = {}".format(
                        consts.LOGS_STARTS_WITH, __method_name, data
                    )
                )
                checkpoint_obj.post(json.dumps(data))
            else:
                applogger.info(
                    "{}:(method = {}), Data Len = {}".format(
                        consts.LOGS_STARTS_WITH, __method_name, len(data)
                    )
                )
                checkpoint_obj.post(data)
            applogger.info(
                "{}:(method = {}), Data posted to azure storage".format(
                    consts.LOGS_STARTS_WITH, __method_name
                )
            )
        except TypeError as type_error:
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, __method_name, type_error
                )
            )
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def get_infoblox_stream_response_obj(self, url, query_parameters=None):
        """This function sends a request to the specified URL with optional query parameters.
        It retries the request based on the MAX_RETRIES constant.

        Args:
            url: The URL to send the request to
            query_parameters: Optional query parameters (default is None)

        Returns:
            The response object from the URL request

        Raises:
            InfobloxException: If the request fails after maximum retries or encounters an exception
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            max_retries = consts.MAX_RETRIES
            for _ in range(max_retries):
                applogger.info(
                    "{}:(method = {}), url = {}, query_param = {}".format(
                        consts.LOGS_STARTS_WITH, __method_name, url, query_parameters
                    )
                )
                response = requests.get(
                    url=url, headers=self.headers, params=query_parameters, stream=True
                )
                if response.status_code == 200:
                    applogger.info(
                        "{}:(method = {}), Status Code = {}".format(
                            consts.LOGS_STARTS_WITH, __method_name, response.status_code
                        )
                    )
                    return response
                elif response.status_code == 500:
                    applogger.error(
                        self.log_error.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            "Status Code = 500, Internal Server Error",
                        )
                    )
                    continue
                elif response.status_code == 401:
                    applogger.error(
                        self.log_error.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            "Status Code = 401, Unauthorized, Provide valid API TOKEN in Environment Variable",
                        )
                    )
                    raise InfobloxException()
                elif response.status_code == 403:
                    applogger.error(
                        self.log_error.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            "Status Code = 403, Forbidden, user does not have access to this API",
                        )
                    )
                    raise InfobloxException()
                else:
                    applogger.error(
                        self.log_error.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            "Status Code = {}, {}".format(
                                response.status_code, response.content
                            ),
                        )
                    )
                    raise InfobloxException()
            applogger.error(
                self.log_error.format(
                    consts.LOGS_STARTS_WITH, __method_name, "Max retries reached"
                )
            )
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def authenticate_infoblox_api(self):
        """A function to authenticate the Infoblox API."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.headers.update({"Authorization": "Token {}".format(consts.API_TOKEN)})
            applogger.info(
                "{}:(method = {}), Headers = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, self.headers
                )
            )
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def url_builder(self, endpoint, path_variable=None):
        """Builds a URL based on the provided endpoint and optional path variable.

        Args:
            endpoint: The base endpoint to build the URL.
            path_variable: Optional path variable to append to the endpoint.

        Returns:
            The constructed URL.

        Raises:
            InfobloxException: When an Infoblox related exception occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if path_variable:
                url = consts.BASE_URL.format(endpoint.format(path_variable))
            else:
                url = consts.BASE_URL.format(endpoint)
            if consts.FIELDS != "all":
                url += "?fields={}".format(consts.FIELDS)

            return url
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def add_xh_to_iso_time_string(self, date_time, x):
        """A function that adds x hours to a given ISO formatted date and time string.

        Args:
            date_time (str): The input date and time string in the format "%Y-%m-%d %H:%M:%S.%f"
            x (int): The number of hours to add to the input date and time.

        Returns:
            str: The new date and time string after adding x hours in the format "%Y-%m-%d %H:%M:%S.%f".

        Raises:
            InfobloxException: When an Infoblox related exception occurs.
            Exception: When any other exception occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                "{}:(method = {}), to_date = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, date_time
                )
            )
            date_time_obj = datetime.datetime.strptime(
                date_time, "%Y-%m-%d %H:%M:%S.%f"
            )
            date_time_obj = date_time_obj + datetime.timedelta(hours=x)
            new_date_time = date_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            applogger.info(
                "{}:(method = {}), from_date = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, new_date_time
                )
            )
            return new_date_time
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def iso_to_epoch_str(self, date_time):
        """A function that converts an ISO formatted date and time string to epoch time.

        Args:
            date_time (str): The input date and time string in the format "%Y-%m-%d %H:%M:%S.%f"

        Returns:
            str: The epoch time as a string.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            date_time_obj = datetime.datetime.strptime(
                date_time, "%Y-%m-%d %H:%M:%S.%f"
            )
            epoch_time = int(date_time_obj.timestamp())
            return str(epoch_time)

        except (TypeError, ValueError) as error:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, error)
            )
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def list_file_names_in_file_share(
        self, parent_dir: ShareDirectoryClient, file_name_prefix
    ):
        """Get list of file names from directory.

        Args:
            parent_dir (ShareDirectory.from_connection_string): Object of ShareDirectory to perform operations
            on file share.

        Returns:
            list: list of files
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            files_list = parent_dir.list_directories_and_files(file_name_prefix)
            if files_list:
                files_list = list(files_list)
            else:
                return []
            file_names = []
            if (len(files_list)) > 0:
                for file in files_list:
                    file_names.append(file["name"])
            applogger.info(
                "{}:(method = {}), Retrieved files for prefix = {}, Total files = {}".format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    file_name_prefix,
                    len(file_names),
                )
            )
            return file_names
        except ResourceNotFoundError:
            applogger.error(
                "{}:(method = {}), No storage directory found.".format(
                    consts.LOGS_STARTS_WITH, __method_name
                )
            )
            return None
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def delete_files_from_azure_storage(
        self, files_list, parent_dir: ShareDirectoryClient
    ):
        """Delete list of files.

        Args:
            files_list (list) : list of files to be deleted
            parent_dir (ShareDirectory.from_connection_string): Object of ShareDirectory to perform operations
            on file share.

        Returns:
            None
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            for file_path in files_list:
                parent_dir.delete_file(file_path)

            applogger.info(
                "{}:(method = {}), Deleted files = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, len(files_list)
                )
            )
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()

    def store_failed_range_in_state_manager(self, from_date, to_date):
        """Store range of date which are failed to fetch.
        Store range in list of dictionary e.g. - [{from_date:"",to_date:""}]

        Args:
            from_date (str): from date of range
            to_date (str): to date of range

        Returns:
            None
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            failed_range_state_manager = StateManager(
                consts.CONN_STRING,
                "failed_range_list_checkpoint_{}".format(consts.TYPE),
                consts.FILE_SHARE_NAME,
            )
            failed_range_list = self.get_checkpoint_data(
                failed_range_state_manager, load_flag=True
            )
            range_to_append = {
                "from_date": from_date,
                "to_date": to_date,
            }
            if failed_range_list is None:
                failed_range_list = []
            failed_range_list.append(range_to_append)
            applogger.info(
                "{}:(method = {}), Total failed range = {}".format(
                    consts.LOGS_STARTS_WITH, __method_name, len(failed_range_list)
                )
            )
            self.post_checkpoint_data(
                failed_range_state_manager, failed_range_list, dump_flag=True
            )
        except Exception as err:
            applogger.error(
                self.log_error.format(consts.LOGS_STARTS_WITH, __method_name, err)
            )
            raise InfobloxException()
