import inspect
import json
import datetime
from azure.storage.fileshare import ShareDirectoryClient
from azure.core.exceptions import ResourceNotFoundError
from .logger import applogger
from .state_manager import StateManager
from .infoblox_exception import InfobloxException
from . import consts


class Utils:
    def __init__(self, azure_function_name):
        self.azure_function_name = azure_function_name
        self.log_format = consts.LOG_FORMAT
        self.headers = {}

    def check_environment_var_exist(self, environment_var):
        """A function to check the existence of required environment variables.
        Logs the validation process and completion. Raises InfobloxException if any required field is missing.

        Args:
            environment_var(list) : variables to check for existence
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:

            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Validating Environment Variables",
                )
            )
            missing_required_field = False
            for i in environment_var:
                key, val = next(iter(i.items()))
                if (val is None) or (val == ""):
                    missing_required_field = True
                    applogger.error(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Environment variable {} is not set".format(key),
                        )
                    )
            if missing_required_field:
                applogger.error(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Validation failed",
                    )
                )
                raise InfobloxException()
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Validation Complete",
                )
            )
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Unexpected error : Error-{}".format(err),
                )
            )
            raise InfobloxException()

    def get_checkpoint_data(self, checkpoint_obj: StateManager, load_flag=False):
        """A function to get checkpoint data from a StateManager object.
        It retrieves the checkpoint data and logs it if the load flag is set to True.

        Args:
            checkpoint_obj (StateManager): The StateManager object to retrieve checkpoint data from.
            load_flag (bool): A flag indicating whether to load the data as JSON (default is False).

        Returns:
            The retrieved checkpoint data.

        Raises:
            InfobloxException: When an Infoblox related exception occurs.
            Exception: When any other exception occurs.

        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint_data = checkpoint_obj.get()
            if load_flag and checkpoint_data:
                checkpoint_data = json.loads(checkpoint_data)
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Checkpoint fetch with json.loads",
                    )
                )
                return checkpoint_data
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Checkpoint fetch without json.loads",
                )
            )
            return checkpoint_data
        except json.decoder.JSONDecodeError as json_error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "JSONDecodeError error : Error-{}".format(json_error),
                )
            )
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Unexpected error : Error-{}".format(err),
                )
            )
            raise InfobloxException()

    def post_checkpoint_data(self, checkpoint_obj: StateManager, data, dump_flag=False):
        """A function to post checkpoint data.
        It posts the data to a checkpoint object based on the dump_flag parameter.

        Args:
            checkpoint_obj (StateManager): The StateManager object to post data to.
            data: The data to be posted.
            dump_flag (bool): A flag indicating whether to dump the data as JSON before posting (default is False).

        Raises:
            TypeError: When a type error occurs.
            Exception: When any other exception occurs.
            InfobloxException: When an Infoblox related exception occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if dump_flag:
                applogger.debug(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Posting data = {}".format(data),
                    )
                )
                checkpoint_obj.post(json.dumps(data))
            else:
                applogger.debug(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Posting data with Len = {}".format(len(data)),
                    )
                )
                checkpoint_obj.post(data)
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Data posted to azure storage",
                )
            )
        except TypeError as type_error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Type error : Error-{}".format(type_error),
                )
            )
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Unexpected error : Error-{}".format(err),
                )
            )
            raise InfobloxException()

    def authenticate_infoblox_api(self):
        """A function to authenticate the Infoblox API."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.headers.update({"Authorization": "Token {}".format(consts.API_TOKEN)})
            applogger.debug(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Headers = {}".format(self.headers),
                )
            )
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Unexpected error : Error-{}".format(err),
                )
            )
            raise InfobloxException()

    def add_xh_to_iso_time_string(self, date_time, x):
        """A function that adds x hours to a given ISO formatted date and time string.

        Args:
            date_time (str): The input date and time string in the format "%Y-%m-%d %H:%M:%S.%f"
            x (int): The number of hours to add to the input date and time.

        Returns:
            str: The new date and time string after adding x hours in the format "%Y-%m-%d %H:%M:%S.%f".

        Raises:
            InfobloxException: When an Infoblox related exception occurs.
            Exception: When any other exception occurs.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Before = {}".format(date_time),
                )
            )
            date_time_obj = datetime.datetime.strptime(
                date_time, "%Y-%m-%d %H:%M:%S.%f"
            )
            date_time_obj = date_time_obj + datetime.timedelta(hours=x)
            new_date_time = date_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "After = {}".format(date_time),
                )
            )
            return new_date_time
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Unexpected error : Error-{}".format(err),
                )
            )
            raise InfobloxException()

    def iso_to_epoch_str(self, date_time):
        """A function that converts an ISO formatted date and time string to epoch time.

        Args:
            date_time (str): The input date and time string in the format "%Y-%m-%d %H:%M:%S.%f"

        Returns:
            str: The epoch time as a string.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            date_time_obj = datetime.datetime.strptime(
                date_time, "%Y-%m-%d %H:%M:%S.%f"
            )
            epoch_time = int(date_time_obj.timestamp())
            return str(epoch_time)

        except (TypeError, ValueError) as error:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Type/Value error : Error-{}".format(error),
                )
            )
            raise InfobloxException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Unexpected error : Error-{}".format(err),
                )
            )
            raise InfobloxException()

    def list_file_names_in_file_share(
        self, parent_dir: ShareDirectoryClient, file_name_prefix
    ):
        """Get list of file names from directory.

        Args:
            parent_dir (ShareDirectory.from_connection_string): Object of ShareDirectory to perform operations
            on file share.

        Returns:
            list: list of files
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            files_list = list(parent_dir.list_directories_and_files(file_name_prefix))
            file_names = []
            if (len(files_list)) > 0:
                for file in files_list:
                    file_names.append(file["name"])
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Retrieved files for prefix = {}, Total files = {}".format(
                        file_name_prefix,
                        len(file_names),
                    ),
                )
            )
            return file_names
        except ResourceNotFoundError:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "No storage directory found",
                )
            )
            return None
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Unexpected error : Error-{}".format(err),
                )
            )
            raise InfobloxException()

    def delete_files_from_azure_storage(
        self, files_list, parent_dir: ShareDirectoryClient
    ):
        """Delete list of files.

        Args:
            files_list (list) : list of files to be deleted
            parent_dir (ShareDirectory.from_connection_string): Object of ShareDirectory to perform operations
            on file share.

        Returns:
            None
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            for file_path in files_list:
                parent_dir.delete_file(file_path)

            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Deleted files = {}".format(len(files_list)),
                )
            )
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Unexpected error : Error-{}".format(err),
                )
            )
            raise InfobloxException()
