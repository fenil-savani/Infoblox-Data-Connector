"""Get mimecast cg data and ingest to custom table in sentinel."""

import inspect
import json
import time
from random import randrange
import gzip
import aiohttp
import asyncio
from aiohttp.client_exceptions import (
    ClientError,
    ServerTimeoutError,
    ClientResponseError,
)
from ..SharedCode import consts
from ..SharedCode.mimecast_exception import MimecastException, MimecastTimeoutException
from ..SharedCode.logger import applogger
from ..SharedCode.state_manager import StateManager
from ..SharedCode.utils import Utils
from ..SharedCode.sentinel import post_data_async


class MimecastCGToSentinel(Utils):
    """Class for ingest the data from mimecast to sentinel."""

    def __init__(self, start_time) -> None:
        """Initialize MimecastDLPToSentinel object."""
        super().__init__(consts.SEG_DLP_FUNCTION_NAME)
        self.check_environment_var_exist(
            [
                {"Base_Url": consts.BASE_URL},
                {"WorkspaceID": consts.WORKSPACE_ID},
                {"WorkspaceKey": consts.WORKSPACE_KEY},
                {"Mimecast_Client_ID": consts.MIMECAST_CLIENT_ID},
                {"Mimecast_Client_Secret": consts.MIMECAST_CLIENT_SECRET},
            ]
        )
        self.authenticate_mimecast_api()
        self.start = start_time
        self.checkpoint_obj = StateManager(
            consts.CONN_STRING, "Checkpoint-SEG-CG", consts.FILE_SHARE_NAME
        )

    async def get_mimecast_cg_data_in_sentinel(self):
        """Get mimecast cg data and ingest data to sentinel, initialization method."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Start fetching cg endpoint data using batch and async",
                )
            )
            await self.get_batch_data_urls_from_api()
        except MimecastTimeoutException:
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Mimecast: 9:00 mins executed hence breaking.",
                )
            )
            return
        except MimecastException:
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()

    async def get_batch_data_urls_from_api(self):
        """Get batch data urls from api."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            checkpoint_data = self.get_checkpoint_data(self.checkpoint_obj)
            next_page = None
            if checkpoint_data:
                next_page = checkpoint_data.get("nextPage")
            else:
                checkpoint_data = {}
            url = "{}{}".format(consts.BASE_URL, consts.ENDPOINTS["SEG_CG"])

            params = {"type": consts.SEG_CG_TYPES, "pageSize": consts.ASYNC_PAGE_SIZE}
            page = 1
            while True:
                if int(time.time()) >= self.start + consts.FUNCTION_APP_TIMEOUT_SECONDS:
                    raise MimecastTimeoutException()
                if next_page:
                    params["nextPage"] = next_page
                applogger.debug(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Params = {}, url = {}, page {}".format(params, url, page),
                    )
                )
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Iterating page {}".format(page),
                    )
                )
                response = self.make_rest_call(method="GET", url=url, params=params)
                next_page = response.get("@nextPage")
                values = response.get("value")
                if len(values) == 0:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "No more data to fetch",
                        )
                    )
                    break

                url_list = [val.get("url") for val in values]

                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Found {} urls in response in page {}".format(
                            len(url_list), page
                        ),
                    )
                )
                result = await self.process_s3_bucket_urls(url_list)
                applogger.debug(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Next token = {}".format(next_page),
                    )
                )
                if result:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Complete processing s3 bucket urls for page {}".format(
                                page
                            ),
                        )
                    )
                    checkpoint_data.update({"nextPage": next_page})
                    self.post_checkpoint_data(self.checkpoint_obj, checkpoint_data)
                page += 1

        except MimecastTimeoutException:
            raise MimecastTimeoutException()
        except MimecastException:
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()

    async def process_s3_bucket_urls(self, url_list):
        __method_name = inspect.currentframe().f_code.co_name
        try:
            async with aiohttp.ClientSession() as session:
                tasks = []
                for index, url in enumerate(url_list):
                    task = asyncio.create_task(
                        self.fetch_unzip_and_ingest_s3_url_data(index+1, session, url)
                    )
                    tasks.append(task)
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "{} tasks created".format(len(tasks)),
                    )
                )
                results = await asyncio.gather(*tasks, return_exceptions=True)
            success_count = 0
            for _, result in enumerate(results):
                if result:
                    success_count += 1
            if success_count == len(url_list):
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "All tasks are completed successfully",
                    )
                )
            else:
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "{} tasks failed".format(len(url_list) - success_count),
                    )
                )
            return True
        except MimecastException:
            raise MimecastException()
        except aiohttp.ClientError as session_err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.CLIENT_ERROR_MSG.format(
                        "Error creating aiohttp.ClientSession: {}".format(session_err)
                    ),
                )
            )
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_MSG.format(err),
                )
            )
            raise MimecastException()

    async def decompress_and_make_json(self, index, response):
        __method_name = inspect.currentframe().f_code.co_name
        try:
            applogger.info(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Read zip, Decompress zip and make json from events for task {}".format(index),
                )
            )
            gzipped_content = await response.read()
            decompressed_data = gzip.decompress(gzipped_content)
            decompressed_content = decompressed_data.decode("utf-8", errors="replace")
            json_objects = [
                json.loads(obj) for obj in decompressed_content.splitlines()
            ]
            return json_objects
        except MimecastException:
            raise MimecastException()
        except aiohttp.ClientError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.CLIENT_ERROR_MSG.format(
                        "Error reading response: {}, for task = {}".format(err, index)
                    ),
                )
            )
            raise MimecastException()
        except (OSError, IOError) as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Error decompressing data: {}, for task = {}".format(err, index),
                )
            )
            raise MimecastException()
        except UnicodeDecodeError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Error decoding decompressed data: {}, for task = {}".format(
                        err, index
                    ),
                )
            )
            raise MimecastException()
        except json.JSONDecodeError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.JSON_DECODE_ERROR_MSG.format(
                        "Error parsing JSON: {}, for task = {}".format(err, index)
                    ),
                )
            )
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_TASK_MSG.format(err, index),
                )
            )
            raise MimecastException()

    async def fetch_unzip_and_ingest_s3_url_data(
        self, index, session: aiohttp.ClientSession, url
    ):
        __method_name = inspect.currentframe().f_code.co_name
        try:
            response = await self.make_async_call(session, url, index)
            response_json = await self.decompress_and_make_json(index, response)
            if len(response_json) > 0:
                applogger.info(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Data len = {}, Ingesting data to sentinel for task = {}".format(len(response_json), index),
                    )
                )
                await post_data_async(
                    index,
                    json.dumps(response_json),
                    session,
                    consts.TABLE_NAME["SEG_CG"],
                )
                return True
        except MimecastException:
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_TASK_MSG.format(err, index),
                )
            )
            raise MimecastException()

    async def make_async_call(self, session, url, index):
        __method_name = inspect.currentframe().f_code.co_name
        try:
            for i in range(consts.MAX_RETRIES):
                applogger.debug(
                    self.log_format.format(
                        consts.LOGS_STARTS_WITH,
                        __method_name,
                        self.azure_function_name,
                        "Get Call, for task = {}".format(index),
                    )
                )
                response = await session.get(url)

                if response.status >= 200 and response.status <= 299:
                    applogger.info(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Success, Status code : {} for task = {}".format(
                                response.status, index
                            ),
                        )
                    )
                    return response
                elif response.status == 429:
                    applogger.error(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Too Many Requests, Status code : {}, Retrying... {} for task = {}".format(
                                response.status, i, index
                            ),
                        )
                    )
                    time.sleep(randrange(2, 10))
                    continue
                else:
                    applogger.error(
                        self.log_format.format(
                            consts.LOGS_STARTS_WITH,
                            __method_name,
                            self.azure_function_name,
                            "Unexpected Error = {}, Status code : {} for task = {}".format(
                                response.text, response.status, index
                            ),
                        )
                    )
                    raise MimecastException()
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Max retries exceeded, for task = {}".format(index),
                )
            )
            raise MimecastException()
        except MimecastException:
            raise MimecastException()
        except ClientResponseError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Client response error: {} - {}, for task = {}".format(
                        err.status, err.message, index
                    ),
                )
            )
            raise MimecastException()
        except ServerTimeoutError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Server timeout error: {}, for task = {}".format(err, index),
                )
            )
            raise MimecastException()
        except ClientError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Client error: {}, for task = {}".format(err, index),
                )
            )
            raise MimecastException()
        except asyncio.TimeoutError as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    "Request timeout error: {}, for task = {}".format(err, index),
                )
            )
            raise MimecastException()
        except Exception as err:
            applogger.error(
                self.log_format.format(
                    consts.LOGS_STARTS_WITH,
                    __method_name,
                    self.azure_function_name,
                    consts.UNEXPECTED_ERROR_TASK_MSG.format(err, index),
                )
            )
            raise MimecastException()
